﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inventory.Application.ViewModel
{
    public class CustomerTypeVm
    {
        public long CustomerTypeId { get; set; }
        public string CustomerTypeName { get; set; }
    }
}
