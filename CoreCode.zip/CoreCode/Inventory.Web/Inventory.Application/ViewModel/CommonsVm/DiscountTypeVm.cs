﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inventory.Application.ViewModel
{
    public class DiscountTypeVm
    {
        public long DiscounttTypeId { get; set; }
        public string DiscountName { get; set; }
    }
}
