﻿    using System;
using System.Collections.Generic;
using System.Text;

namespace Inventory.Application.ViewModel
{
   public class CountryVm
    {
        public long CountryId { get; set; }
        public string CountryName { get; set; }
    }
}
