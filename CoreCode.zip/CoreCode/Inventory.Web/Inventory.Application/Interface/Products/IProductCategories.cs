﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inventory.Application.Interface.Products
{
    public interface IProductCategories
    {
    }
}
