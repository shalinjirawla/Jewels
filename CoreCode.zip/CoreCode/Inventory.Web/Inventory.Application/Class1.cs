﻿using System;

namespace Inventory.Application
{
    public class Class1
    {
    }
}
