﻿using System;

namespace Inventory.Web.Core
{
    public class Class1
    {
    }
}
