﻿using System;

namespace Inventory.EntityFrameworkCore
{
    public class Class1
    {
    }
}
