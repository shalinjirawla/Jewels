﻿using System;

namespace Inventory.Core
{
    public class Class1
    {
    }
}
