﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Inventory.Core.Models.ApplicationUser
{
    public class ApplicationUser : IdentityUser
    {
    }
}
